import { Test } from './modules/test.js';
import * as $ from 'jquery';

$('.test').html(Test());