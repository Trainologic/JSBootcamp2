"use strict";
var test_js_1 = require("./modules/test.js");
var $ = require("jquery");
$('.test').html(test_js_1.Test());
//# sourceMappingURL=app.js.map