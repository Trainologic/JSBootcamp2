export function Test(): string {
    return 'test';
}