"use strict";
function Test() {
    return 'test';
}
exports.Test = Test;
//# sourceMappingURL=test.js.map